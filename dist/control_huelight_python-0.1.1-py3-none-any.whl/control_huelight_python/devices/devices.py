from phue import Bridge as phue_Bridge
from phue import Light as phue_Light
import logging


class HueLight(object):
    def __init__(self, name: str = "Hue color lamp bedroom 1", id: int = 5) -> None:
        """ Initialize the HueLight object
        Args:
            name (str, optional): Name of the light that appear on the Hue app. Defaults to "Hue color lamp bedroom 1".
            id (int, optional): ID of the light defined by the Hue bridge. Defaults to 5.
        """
        super().__init__()
        self.name = name
        self.id = id
        self.phue_light = None  # Light() object from phue package

    # def assign_bridge(self, bridge: phue_Bridge) -> None:
    #     """ Assign the Hue bridge object to the HueLight object
    #     Args:
    #         bridge (Bridge): Bridge object from phue package
    #     """
    #     self.phue_light = phue_Light(bridge)


class HueBridgeController(object):
    def __init__(
        self,
        bridge_ip: str = "192.168.1.15",
        user_name="x-kHU4Ng800tNMpNIC51mF3l6V1bL9w4AuNB7-pI",
    ) -> None:
        """ Initialize the a Hue Bridge controller for multiple connected devices
        Args:
            bridge_ip (str, optional): IP address of the Hue bridge. Defaults to "192.168.1.15"
            user_name (str, optional): Your user name to log into the Hue bridge. Defaults to "x-kHU4Ng800tNMpNIC51mF3l6V1bL9w4AuNB7-pI".
        """
        super().__init__()
        self.bridge = phue_Bridge(bridge_ip, user_name)
        try:
            self.bridge.connect()
        except RuntimeError as e:
            print("Cannot connect")
            logging.error(e)
            return None
        # Connected lights that are already verified by the user
        self.verified_light_ids = []

    def check_light_connection(self, light: HueLight) -> bool:
        """ Check if the light is connected to the bridge. It will also fulfill missing information about the light
        Args:
            light (HueLight): Light to check
        Returns:
            bool: True if the light is connected to the bridge, False otherwise
        """
        connected = False
        breakpoint()
        if light.name is not None:
            for light_obj in self.bridge.lights:
                logging.debug(f"-> available light: {light_obj.name}")
                if light.name == light_obj.name:
                    light.id = light_obj.light_id
                    connected = True
                    self.verified_light_ids.append(light.id)
                    logging.debug(f"Light {light.name} is connected")
                    # break
        elif light.id is not None:
            for light_obj in self.bridge.lights:
                if light.id == light_obj.light_id:
                    light.name = light_obj.name
                    connected = True
                    self.verified_light_ids.append(light.id)
                    logging.debug(f"Light {light.name} is connected")
                    # break
        else:
            logging.error("Light must be given with either name or id. None is given!")
        return connected
