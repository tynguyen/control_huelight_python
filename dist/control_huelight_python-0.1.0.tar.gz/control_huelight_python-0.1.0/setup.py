# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['control_huelight_python',
 'control_huelight_python.devices',
 'control_huelight_python.utils']

package_data = \
{'': ['*']}

install_requires = \
['phue>=1.1,<2.0']

setup_kwargs = {
    'name': 'control-huelight-python',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'tynguyen',
    'author_email': 'tynguyen@seas.upenn.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
